import weather from '../weather.webp';
import shoppingCart from '../shoppingcart.webp';
import twitter from '../twitter.webp';
import todoList from '../todoList.webp';
import wheresWaldo from '../wheresWaldo.webp';

export const images = {
  weather,
  shoppingCart,
  twitter,
  todoList,
  wheresWaldo,
};
